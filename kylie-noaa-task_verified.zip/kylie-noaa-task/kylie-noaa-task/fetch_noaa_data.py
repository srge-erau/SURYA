#!/usr/bin/env python3
"""
fetch_noaa_data.py
------------------
Compile NOAA SWPC space weather data for comparison with Surya AI model predictions.
Targets specific event windows relevant to the SmallSat 2026 paper.

Data sources:
  - GOES X-ray flare event lists (NCEI / SWPC archives)
  - 3-day space weather predictions with flare probabilities (NCEI archive)
  - Kp and Dst geomagnetic indices (GFZ Potsdam / NASA OMNI)
  - GOES X-ray flux time series (NCEI)

Target events (all in Surya test window 2020-2024):
  1. February 2022 Starlink loss (G1 storm, 38 satellites lost)
  2. May 2024 Gannon storm (G5, strongest in 20 years)
  3. October 2024 X9.0 flare cluster
  4. December 2024 multi-X-class event
  5. Quiet baseline period (e.g., Feb 2020)

Output: CSV files in ../data/ for each event and data type.

Author: SRGE Laboratory, Embry-Riddle Aeronautical University
"""

import os
import re
import sys
import json
import time
import argparse
from datetime import datetime, timedelta
from pathlib import Path

import requests
import pandas as pd
import numpy as np


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Event windows: (name, start_date, end_date, description)
EVENTS = [
    ("2022_feb_starlink", "2022-01-28", "2022-02-15",
     "Feb 2022 Starlink loss: G1 storm caused 38/49 satellite de-orbits"),
    ("2024_may_gannon", "2024-05-01", "2024-05-18",
     "May 2024 Gannon storm: G5, X8.7 flare, strongest in 20 years"),
    ("2024_oct_xflares", "2024-09-28", "2024-10-10",
     "Oct 2024: X7.1 and X9.0 flares from AR 3842"),
    ("2024_dec_cluster", "2024-12-25", "2025-01-05",
     "Dec 2024: 3 X-class + 20 M-class flares in 24 hours, G3 watch"),
    ("2020_feb_quiet", "2020-02-01", "2020-02-28",
     "Feb 2020: Quiet baseline period near solar minimum"),
]

HEADERS = {
    "User-Agent": "SRGE-HELIO-Research/1.0 (Embry-Riddle Aeronautical University)"
}


# ---------------------------------------------------------------------------
# 1. GOES X-ray Flare Event Lists from SWPC
# ---------------------------------------------------------------------------

def fetch_swpc_event_reports(start_date: str, end_date: str, event_name: str):
    """
    Fetch SWPC solar event reports from the NCEI archive.
    Format: https://services.swpc.noaa.gov/json/solar_events.json (recent only)
    For historical: NCEI FTP/HTTP archive with YYYYMMDDevents.txt files

    Falls back to parsing the SWPC JSON API for recent events.
    """
    print(f"\n--- Fetching SWPC event reports for {event_name} ---")
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)

    all_events = []

    # Try NCEI HTTPS archive for daily event files
    # URL pattern: https://www.ncei.noaa.gov/data/space-weather/access/...
    # Alternative: SWPC FTP at ftp://ftp.swpc.noaa.gov/pub/warehouse/{YYYY}/
    base_url = "https://services.swpc.noaa.gov/json/goes/primary/xray-flares-latest.json"

    # For historical data, use the warehouse
    # Pattern: ftp://ftp.swpc.noaa.gov/pub/warehouse/YYYY/YYYYevents.tar.gz
    # Or individual: ftp.swpc.noaa.gov/pub/indices/events/YYYYMMDDevents.txt

    # Strategy: Use the SWPC JSON API for recent data, and construct
    # event list from GOES X-ray flux for historical data
    current = start
    while current <= end:
        datestr = current.strftime("%Y%m%d")
        year = current.strftime("%Y")

        year = current.strftime("%Y")
        month = current.strftime("%m")

        # NCEI archive: .../YYYY/MM/YYYYMMDDSGAS.txt
        url = (f"https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/"
               f"daily_reports/solar_geophysical_activity_summaries/"
               f"{year}/{month}/{datestr}SGAS.txt")

        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            if resp.status_code == 200:
                events_from_sgas = parse_sgas_flares(resp.text, current)
                all_events.extend(events_from_sgas)
                print(f"  {datestr}: {len(events_from_sgas)} flare events found")
            else:
                print(f"  {datestr}: HTTP {resp.status_code} (trying event reports)")
                # Try NCEI event reports: .../YYYY/MM/YYYYMMDDevents.txt
                alt_url = (f"https://www.ngdc.noaa.gov/stp/space-weather/"
                           f"swpc-products/daily_reports/solar_event_reports/"
                           f"{year}/{month}/{datestr}events.txt")
                resp2 = requests.get(alt_url, headers=HEADERS, timeout=15)
                if resp2.status_code == 200:
                    events_from_sgas = parse_sgas_flares(resp2.text, current)
                    all_events.extend(events_from_sgas)
                    print(f"  {datestr}: {len(events_from_sgas)} flare events (alt)")
        except requests.RequestException as e:
            print(f"  {datestr}: Request failed: {e}")

        current += timedelta(days=1)
        time.sleep(0.3)  # Rate limiting

    if all_events:
        df = pd.DataFrame(all_events)
        outpath = DATA_DIR / f"noaa_flare_events_{event_name}.csv"
        df.to_csv(outpath, index=False)
        print(f"  Saved {len(df)} events to {outpath}")
        return df
    else:
        print("  No events retrieved from SGAS. Trying GOES X-ray JSON API...")
        return fetch_goes_xray_events_json(start_date, end_date, event_name)


def parse_sgas_flares(text: str, date: pd.Timestamp) -> list:
    """
    Parse SGAS (Solar and Geophysical Activity Summary) text for flare events.
    
    Real SGAS event table format (varies, two common layouts):
    Layout 1 (event report table):
      Begin  Max  End  Obs  Q  Type  Freq    Particulars    Reg#
      0113   0120 0125 G15  5  XRA   1-8A    M1.4 2.3E-03  2939
    Layout 2 (prose with embedded class references):
      Region 2939 produced an M1.4/1N flare at 03/0113Z
    
    Also handles dd/HHMM time formats (e.g. 03/0113).
    """
    events = []

    # Pattern 1: Tabular format with HHMM times and GOES class in same line
    # Matches lines with 3-4 digit time groups and a GOES class (B/C/M/X + number)
    table_pattern = re.compile(
        r'(\d{3,4})\s+'           # begin time (HHMM or HMM)
        r'(\d{3,4})\s+'           # max time
        r'(\d{3,4})\s+'           # end time
        r'.*?'                     # obs, quality, type, freq (variable)
        r'([BCMX]\d+\.?\d*)',     # GOES class anywhere after the times
        re.IGNORECASE
    )

    # Pattern 2: dd/HHMM format (e.g. "03/0113-03/0125-03/0120")
    slash_pattern = re.compile(
        r'(\d{2}/\d{4})\s*-\s*'   # begin (dd/HHMM)
        r'(\d{2}/\d{4})\s*-\s*'   # end (dd/HHMM)
        r'(\d{2}/\d{4})',          # max (dd/HHMM)
        re.IGNORECASE
    )

    # Pattern 3: GOES class anywhere in line with region number
    class_pattern = re.compile(
        r'([BCMX]\d+\.?\d*)',
        re.IGNORECASE
    )

    for line in text.split('\n'):
        line_stripped = line.strip()
        if not line_stripped:
            continue

        goes_class = None
        begin_time = ""
        max_time = ""
        end_time = ""
        location = ""
        region = ""

        # Try tabular format first
        match = table_pattern.search(line_stripped)
        if match:
            bt = match.group(1).zfill(4)
            mt = match.group(2).zfill(4)
            et = match.group(3).zfill(4)
            begin_time = f"{bt[:2]}:{bt[2:]}"
            max_time = f"{mt[:2]}:{mt[2:]}"
            end_time = f"{et[:2]}:{et[2:]}"
            goes_class = match.group(4).upper()

        # Try dd/HHMM format
        if not goes_class:
            slash_match = slash_pattern.search(line_stripped)
            if slash_match:
                begin_time = slash_match.group(1)[-4:]
                begin_time = f"{begin_time[:2]}:{begin_time[2:]}"
                end_time = slash_match.group(2)[-4:]
                end_time = f"{end_time[:2]}:{end_time[2:]}"
                max_time = slash_match.group(3)[-4:]
                max_time = f"{max_time[:2]}:{max_time[2:]}"
                cls_match = class_pattern.search(line_stripped)
                if cls_match:
                    goes_class = cls_match.group(1).upper()

        if goes_class and goes_class[0] in ('M', 'X', 'C', 'B'):
            # Extract location (e.g. S26W60, N15E30)
            loc_match = re.search(r'([NS]\d{1,2}[EW]\d{1,2})', line_stripped)
            if loc_match:
                location = loc_match.group(1)

            # Extract region number (last 4-5 digit number on the line)
            reg_matches = re.findall(r'\b(\d{4,5})\b', line_stripped)
            if reg_matches:
                region = reg_matches[-1]  # Last match is typically the region

            events.append({
                "date": date.strftime("%Y-%m-%d"),
                "begin_utc": begin_time,
                "max_utc": max_time,
                "end_utc": end_time,
                "location": location,
                "goes_class": goes_class,
                "region": region,
                "source": "SWPC_SGAS",
            })

    return events


def fetch_goes_xray_events_json(start_date: str, end_date: str,
                                 event_name: str) -> pd.DataFrame:
    """
    Fetch GOES X-ray flare events from SWPC JSON API.
    This API provides recent events (typically last 30 days).
    For historical, we construct from GOES X-ray flux data.
    """
    url = "https://services.swpc.noaa.gov/json/goes/primary/xray-flares-7-day.json"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            df = pd.DataFrame(data)
            if not df.empty:
                df["begin_time"] = pd.to_datetime(df.get("begin_time", ""))
                mask = (
                    (df["begin_time"] >= start_date) &
                    (df["begin_time"] <= end_date)
                )
                df_filtered = df[mask]
                outpath = DATA_DIR / f"noaa_flare_events_{event_name}.csv"
                df_filtered.to_csv(outpath, index=False)
                print(f"  Saved {len(df_filtered)} events (JSON API)")
                return df_filtered
    except Exception as e:
        print(f"  JSON API failed: {e}")

    print("  Note: For historical events, use the GOES XRS data directly.")
    print("  See fetch_goes_xray_flux() for continuous X-ray flux time series.")
    return pd.DataFrame()


# ---------------------------------------------------------------------------
# 2. GOES X-ray Flux Time Series
# ---------------------------------------------------------------------------

def fetch_goes_xray_flux(start_date: str, end_date: str, event_name: str):
    """
    Fetch GOES X-ray flux data from NCEI.
    For the paper, we need the continuous 1-8 Angstrom flux to identify
    flare events and compare timing with Surya predictions.

    NCEI provides GOES-R XRS data at:
    https://data.ngdc.noaa.gov/platforms/solar-space-observing-satellites/goes/
    """
    print(f"\n--- Fetching GOES X-ray flux for {event_name} ---")

    # SWPC provides recent data via JSON
    # For 1-minute averages (last 7 days only):
    url_1min = "https://services.swpc.noaa.gov/json/goes/primary/xrays-1-day.json"
    # For 6-hour data (recent):
    url_6hr = "https://services.swpc.noaa.gov/json/goes/primary/xrays-6-hour.json"

    # For historical, we need NCEI archive
    # GOES-16 XRS science data: https://www.ncei.noaa.gov/data/goes-space-environment-monitor/
    # access/science/xrs/goes16/xrsf-l2-avg1m_science/

    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    all_records = []

    # Use NCEI GOES-16 XRS monthly files
    # URL pattern for 1-minute averages:
    # https://data.ngdc.noaa.gov/platforms/solar-space-observing-satellites/goes/goes16/
    # l2/data/xrsf-l2-avg1m_science/YYYY/MM/
    # sci_xrsf-l2-avg1m_g16_dYYYYMMDD_vX-X-X.nc

    current_month = start.to_period("M")
    end_month = end.to_period("M")

    print("  Note: GOES XRS data requires NetCDF download from NCEI.")
    print("  For the paper, use the NOAA SWPC event lists + Kp/Dst indices instead.")
    print("  The GOES XRS data can supplement as needed for Figure generation.")

    # Create a placeholder info file
    info_path = DATA_DIR / f"goes_xrs_info_{event_name}.txt"
    with open(info_path, "w") as f:
        f.write(f"GOES X-ray Flux Data Source Information\n")
        f.write(f"Event: {event_name}\n")
        f.write(f"Date range: {start_date} to {end_date}\n\n")
        f.write(f"Primary source (GOES-16/17 science data):\n")
        f.write(f"  https://www.ncei.noaa.gov/data/goes-space-environment-monitor/"
                f"access/science/xrs/goes16/xrsf-l2-avg1m_science/\n\n")
        f.write(f"Secondary source (SWPC operational, last 7 days only):\n")
        f.write(f"  https://services.swpc.noaa.gov/json/goes/primary/xrays-7-day.json\n\n")
        f.write(f"File format: NetCDF4\n")
        f.write(f"Variables: xrsb_flux (1-8 Angstrom), xrsa_flux (0.5-4 Angstrom)\n")
        f.write(f"Cadence: 1-minute averages\n")
    print(f"  Saved source info to {info_path}")


# ---------------------------------------------------------------------------
# 3. Geomagnetic Indices (Kp, Dst, Ap)
# ---------------------------------------------------------------------------

def fetch_kp_dst_indices(start_date: str, end_date: str, event_name: str):
    """
    Fetch Kp and Dst geomagnetic indices.

    Kp: Extracted from SGAS files already downloaded (3 Hour K-indices line).
    Dst: WDC Kyoto provisional HTML pages.
    """
    print(f"\n--- Fetching Kp/Dst indices for {event_name} ---")

    # -- Kp: extract from SGAS files (already downloaded) --
    kp_records = extract_kp_from_sgas(start_date, end_date)
    if kp_records:
        df_kp = pd.DataFrame(kp_records)
        outpath = DATA_DIR / f"kp_index_{event_name}.csv"
        df_kp.to_csv(outpath, index=False)
        print(f"  Saved {len(df_kp)} Kp records to {outpath}")
    else:
        print("  Kp: No data extracted from SGAS files.")

    # -- Dst from WDC Kyoto --
    fetch_dst_from_kyoto(start_date, end_date, event_name)


def extract_kp_from_sgas(start_date: str, end_date: str) -> list:
    """
    Download SGAS files and extract the 'Planetary' Kp indices.
    Each SGAS contains 8 three-hourly Kp values for the previous day.
    Line format: 'Boulder 2 3 2 4 2 2 2 2 Planetary 2 3 2 3 2 2 3 2'
    """
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    records = []

    # SGAS for date D reports data from date D-1, so we need D+1
    current = start
    while current <= end + timedelta(days=1):
        datestr = current.strftime("%Y%m%d")
        year = current.strftime("%Y")
        month = current.strftime("%m")

        url = (f"https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/"
               f"daily_reports/solar_geophysical_activity_summaries/"
               f"{year}/{month}/{datestr}SGAS.txt")

        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            if resp.status_code == 200:
                # Find the Planetary K-indices line
                for line in resp.text.split("\n"):
                    if "Planetary" in line and any(c.isdigit() for c in line):
                        # Extract numbers after "Planetary"
                        parts = line.split("Planetary")
                        if len(parts) >= 2:
                            nums = re.findall(r'(\d+)', parts[1])
                            if len(nums) >= 8:
                                # SGAS issued on date D reports D-1
                                report_date = current - timedelta(days=1)
                                for hour_idx in range(8):
                                    kp_val = float(nums[hour_idx])
                                    hour = hour_idx * 3  # 0, 3, 6, 9, 12, 15, 18, 21
                                    dt = report_date.replace(
                                        hour=hour, minute=0, second=0
                                    )
                                    records.append({
                                        "datetime_utc": dt.strftime(
                                            "%Y-%m-%d %H:%M:%S"
                                        ),
                                        "kp": kp_val,
                                        "source": "SWPC_SGAS_Planetary",
                                    })
                                break
        except Exception:
            pass

        current += timedelta(days=1)
        time.sleep(0.2)

    # Filter to date range
    if records:
        df = pd.DataFrame(records)
        df["datetime_utc"] = pd.to_datetime(df["datetime_utc"])
        mask = (
            (df["datetime_utc"] >= start_date) &
            (df["datetime_utc"] <= end_date)
        )
        df = df[mask]
        return df.to_dict("records")
    return records


def fetch_kp_from_gfz(start_date: str, end_date: str) -> list:
    """Fetch Kp index from GFZ Potsdam JSON API (backup)."""
    url = f"https://kp.gfz.de/app/json/?start={start_date}&end={end_date}&index=Kp&status=def"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            records = []
            if "datetime" in data and "Kp" in data:
                for dt, kp in zip(data["datetime"], data["Kp"]):
                    records.append({
                        "datetime_utc": dt,
                        "kp": kp,
                    })
                if "ap" in data:
                    for i, ap in enumerate(data["ap"]):
                        if i < len(records):
                            records[i]["ap"] = ap
            return records
    except Exception as e:
        print(f"  GFZ Kp fetch error: {e}")
    return []


def fetch_kp_from_swpc(start_date: str, end_date: str, event_name: str):
    """Fallback: Fetch Kp from SWPC JSON (recent data only)."""
    url = "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            # First row is header
            if len(data) > 1:
                header = data[0]
                rows = data[1:]
                df = pd.DataFrame(rows, columns=header)
                df["time_tag"] = pd.to_datetime(df["time_tag"])
                mask = (
                    (df["time_tag"] >= start_date) &
                    (df["time_tag"] <= end_date)
                )
                df_filtered = df[mask]
                if not df_filtered.empty:
                    outpath = DATA_DIR / f"kp_index_{event_name}.csv"
                    df_filtered.to_csv(outpath, index=False)
                    print(f"  Saved {len(df_filtered)} Kp records (SWPC)")
    except Exception as e:
        print(f"  SWPC Kp fetch error: {e}")


def fetch_dst_from_kyoto(start_date: str, end_date: str, event_name: str):
    """
    Fetch Dst index from WDC Kyoto HTML pages.
    Working URL: https://wdc.kugi.kyoto-u.ac.jp/dst_provisional/YYYYMM/index.html
    Falls back through: provisional -> realtime
    For data before 2021: dst_final
    """
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)

    all_dst = []
    current_month = start.to_period("M")
    end_month = end.to_period("M")

    while current_month <= end_month:
        year = current_month.year
        month = current_month.month
        ym = f"{year:04d}{month:02d}"

        # Try provisional first (most historical data), then final, then realtime
        for quality in ["provisional", "final", "realtime"]:
            url = f"https://wdc.kugi.kyoto-u.ac.jp/dst_{quality}/{ym}/index.html"
            try:
                resp = requests.get(url, headers=HEADERS, timeout=15)
                if resp.status_code == 200 and "DAY" in resp.text:
                    # Extract the text table from the HTML
                    # The table appears between <pre> tags or as plain text
                    text = resp.text

                    # Try to find the data section with DAY header
                    records = parse_dst_wdc(text, year, month)
                    if records:
                        all_dst.extend(records)
                        print(f"  Dst {year}-{month:02d}: "
                              f"{len(records)} hours ({quality})")
                        break
            except Exception as e:
                continue

        current_month += 1
        time.sleep(0.3)

    if all_dst:
        df_dst = pd.DataFrame(all_dst)
        df_dst["datetime_utc"] = pd.to_datetime(df_dst["datetime_utc"])
        mask = (
            (df_dst["datetime_utc"] >= start_date) &
            (df_dst["datetime_utc"] <= end_date)
        )
        df_dst = df_dst[mask]
        outpath = DATA_DIR / f"dst_index_{event_name}.csv"
        df_dst.to_csv(outpath, index=False)
        print(f"  Saved {len(df_dst)} Dst records to {outpath}")
    else:
        print("  Dst: No data retrieved. Check WDC Kyoto availability.")


def parse_dst_wdc(text: str, year: int, month: int) -> list:
    """
    Parse WDC Kyoto Dst format. Each line has day number followed by
    24 hourly values. Values can be packed without spaces for negatives:
    e.g. "-9-10-11-12" is four values: -9, -10, -11, -12
    
    WDC format: first few chars = day, then 24 values of 4 chars each.
    """
    records = []
    lines = text.strip().split("\n")

    for line in lines:
        line = line.rstrip()
        if not line or len(line) < 20:
            continue

        # Find the day number at the start of the line
        stripped = line.lstrip()
        if not stripped or not stripped[0].isdigit():
            continue

        # Try to extract day number
        day_match = re.match(r'\s*(\d{1,2})\s', line)
        if not day_match:
            continue

        day = int(day_match.group(1))
        if day < 1 or day > 31:
            continue

        # Find where the values start (after the day number)
        rest = line[day_match.end():]

        # Method 1: Try split() first (works when values have spaces)
        parts = rest.split()
        if len(parts) >= 24:
            try:
                for hour in range(24):
                    val = int(parts[hour])
                    dt = datetime(year, month, day, hour)
                    records.append({
                        "datetime_utc": dt.strftime("%Y-%m-%d %H:%M:%S"),
                        "dst_nT": val,
                    })
                continue  # Success, move to next line
            except (ValueError, IndexError):
                pass

        # Method 2: Fixed-width parsing (4 chars per value)
        # This handles packed negatives like "-9-10-11"
        values = []
        i = 0
        while i < len(rest) and len(values) < 24:
            # Skip leading whitespace
            while i < len(rest) and rest[i] == ' ':
                i += 1
            if i >= len(rest):
                break

            # Read a value: optional minus sign + digits
            val_str = ""
            if rest[i] == '-':
                val_str += '-'
                i += 1
            while i < len(rest) and rest[i].isdigit():
                val_str += rest[i]
                i += 1

            if val_str and val_str != '-':
                try:
                    values.append(int(val_str))
                except ValueError:
                    pass

        if len(values) >= 24:
            for hour in range(24):
                dt = datetime(year, month, day, hour)
                records.append({
                    "datetime_utc": dt.strftime("%Y-%m-%d %H:%M:%S"),
                    "dst_nT": values[hour],
                })

    return records


# ---------------------------------------------------------------------------
# 4. SWPC 3-Day Forecast Predictions (what NOAA actually predicted)
# ---------------------------------------------------------------------------

def fetch_swpc_predictions(start_date: str, end_date: str, event_name: str):
    """
    Fetch SWPC 3-day predictions from the NCEI archive.
    These contain the actual flare probability forecasts NOAA issued.

    Format: YYYMMDDdaypre.txt (available 12/2013-present)
    Archive: https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/daily_reports/

    The 'daypre' file contains:
    - Radio Blackout forecast probabilities (R1-R2, R3+)
    - Solar Radiation Storm probabilities (S1+)
    - Geomagnetic Storm probabilities (G1+)
    """
    print(f"\n--- Fetching SWPC 3-day predictions for {event_name} ---")

    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    all_forecasts = []

    current = start
    while current <= end:
        datestr = current.strftime("%Y%m%d")
        year = current.strftime("%Y")
        month = current.strftime("%m")

        # NCEI archive: .../YYYY/MM/YYYYMMDDRSGA.txt
        url = (f"https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/"
               f"daily_reports/reports_solar_geophysical_activity/"
               f"{year}/{month}/{datestr}RSGA.txt")

        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            if resp.status_code == 200:
                forecast = parse_rsga_forecast(resp.text, current)
                if forecast:
                    all_forecasts.append(forecast)
                    print(f"  {datestr}: Forecast retrieved "
                          f"(M-class day1: {forecast.get('m_class_day1_pct', 'N/A')}%)")
            else:
                # Try 3-day forecast: .../YYYY/MM/...three_day_forecast.txt
                url2 = (f"https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/"
                        f"daily_reports/3day_forecast/"
                        f"{year}/{month}/{datestr}0030three_day_forecast.txt")
                resp2 = requests.get(url2, headers=HEADERS, timeout=15)
                if resp2.status_code == 200:
                    forecast = parse_rsga_forecast(resp2.text, current)
                    if forecast:
                        all_forecasts.append(forecast)
                        print(f"  {datestr}: Forecast retrieved (3-day format)")
                else:
                    # Try daypre: .../YYYY/MM/YYMMDDdaypre.txt
                    yy = current.strftime("%y")
                    url3 = (f"https://www.ngdc.noaa.gov/stp/space-weather/"
                            f"swpc-products/daily_reports/daypre/"
                            f"{year}/{month}/{yy}{datestr[2:]}daypre.txt")
                    resp3 = requests.get(url3, headers=HEADERS, timeout=15)
                    if resp3.status_code == 200:
                        forecast = parse_daypre_forecast(resp3.text, current)
                        if forecast:
                            all_forecasts.append(forecast)
                            print(f"  {datestr}: Prediction retrieved (daypre)")
        except requests.RequestException as e:
            print(f"  {datestr}: {e}")

        current += timedelta(days=1)
        time.sleep(0.3)

    if all_forecasts:
        df = pd.DataFrame(all_forecasts)
        outpath = DATA_DIR / f"noaa_forecasts_{event_name}.csv"
        df.to_csv(outpath, index=False)
        print(f"  Saved {len(df)} forecast records to {outpath}")
    else:
        print("  No forecast data retrieved from SWPC text service.")
        print("  Alternative: Use NCEI archive access for historical forecasts.")


def parse_rsga_forecast(text: str, date: pd.Timestamp) -> dict:
    """
    Parse RSGA (Report and Forecast of Solar and Geophysical Activity) text.
    Extract event probabilities section.
    
    Handles two formats:
    Format 1 (per-day rows):
                     Class M   Class X
      04 Feb           30        05
      05 Feb           25        05
    Format 2 (slash-separated):
      Class M   30/25/25
      Class X   05/05/01
    """
    forecast = {"date": date.strftime("%Y-%m-%d"), "source": "SWPC_RSGA"}

    lines = text.split("\n")
    in_probs = False
    day_values_m = []
    day_values_x = []

    for line in lines:
        line_upper = line.upper().strip()

        if "EVENT PROBABILITIES" in line_upper:
            in_probs = True
            continue

        if in_probs:
            # Format 2: slash-separated (CLASS M  30/25/25)
            m_slash = re.search(r'CLASS\s+M\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)', line_upper)
            if m_slash:
                forecast["m_class_day1_pct"] = int(m_slash.group(1))
                forecast["m_class_day2_pct"] = int(m_slash.group(2))
                forecast["m_class_day3_pct"] = int(m_slash.group(3))
                continue

            x_slash = re.search(r'CLASS\s+X\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)', line_upper)
            if x_slash:
                forecast["x_class_day1_pct"] = int(x_slash.group(1))
                forecast["x_class_day2_pct"] = int(x_slash.group(2))
                forecast["x_class_day3_pct"] = int(x_slash.group(3))
                continue

            # Format 1: per-day rows (04 FEB  30  05)
            day_row = re.search(
                r'(\d{1,2})\s+(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)'
                r'\s+(\d+)\s+(\d+)',
                line_upper
            )
            if day_row:
                day_values_m.append(int(day_row.group(3)))
                day_values_x.append(int(day_row.group(4)))
                continue

            # Proton event
            p_match = re.search(r'PROTON\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)', line_upper)
            if p_match:
                forecast["proton_day1_pct"] = int(p_match.group(1))
                forecast["proton_day2_pct"] = int(p_match.group(2))
                forecast["proton_day3_pct"] = int(p_match.group(3))

    # Assign per-day row values
    if day_values_m and "m_class_day1_pct" not in forecast:
        for idx, val in enumerate(day_values_m[:3]):
            forecast[f"m_class_day{idx+1}_pct"] = val
    if day_values_x and "x_class_day1_pct" not in forecast:
        for idx, val in enumerate(day_values_x[:3]):
            forecast[f"x_class_day{idx+1}_pct"] = val

    return forecast if len(forecast) > 2 else None


def parse_daypre_forecast(text: str, date: pd.Timestamp) -> dict:
    """Parse 3-day prediction text file."""
    forecast = {"date": date.strftime("%Y-%m-%d"), "source": "SWPC_DAYPRE"}

    lines = text.split("\n")
    for line in lines:
        line_upper = line.upper().strip()
        # Look for Radio Blackout, Solar Radiation, Geomagnetic lines
        if "R1-R2" in line_upper:
            nums = re.findall(r'(\d+)%', line)
            if len(nums) >= 3:
                forecast["r1r2_day1_pct"] = int(nums[0])
                forecast["r1r2_day2_pct"] = int(nums[1])
                forecast["r1r2_day3_pct"] = int(nums[2])
        if "R3" in line_upper and "GREATER" in line_upper:
            nums = re.findall(r'(\d+)%', line)
            if len(nums) >= 3:
                forecast["r3plus_day1_pct"] = int(nums[0])
                forecast["r3plus_day2_pct"] = int(nums[1])
                forecast["r3plus_day3_pct"] = int(nums[2])
        if "S1" in line_upper and "GREATER" in line_upper:
            nums = re.findall(r'(\d+)%', line)
            if len(nums) >= 3:
                forecast["s1plus_day1_pct"] = int(nums[0])
                forecast["s1plus_day2_pct"] = int(nums[1])
                forecast["s1plus_day3_pct"] = int(nums[2])

    return forecast if len(forecast) > 2 else None


# ---------------------------------------------------------------------------
# 5. Compile summary of event characteristics
# ---------------------------------------------------------------------------

def create_event_summary():
    """Create a summary table of target events for the paper."""
    print("\n--- Creating event summary table ---")

    summary = []
    for name, start, end, desc in EVENTS:
        summary.append({
            "event_id": name,
            "start_date": start,
            "end_date": end,
            "description": desc,
            "in_surya_test_set": "Yes (2020-2024)" if int(start[:4]) >= 2020 else "No",
            "noaa_data_available": "Yes",
        })

    df = pd.DataFrame(summary)
    outpath = DATA_DIR / "event_summary.csv"
    df.to_csv(outpath, index=False)
    print(f"  Saved event summary to {outpath}")
    return df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Fetch NOAA SWPC data for SmallSat paper comparison"
    )
    parser.add_argument(
        "--events", nargs="*", default=None,
        help="Specific event names to fetch (default: all)"
    )
    parser.add_argument(
        "--skip-flares", action="store_true",
        help="Skip flare event report fetching"
    )
    parser.add_argument(
        "--skip-indices", action="store_true",
        help="Skip Kp/Dst index fetching"
    )
    parser.add_argument(
        "--skip-forecasts", action="store_true",
        help="Skip SWPC forecast fetching"
    )
    args = parser.parse_args()

    print("=" * 70)
    print("HELIO SmallSat Paper: NOAA Data Compilation")
    print("=" * 70)

    # Create event summary
    create_event_summary()

    # Process each event
    target_events = EVENTS
    if args.events:
        target_events = [e for e in EVENTS if e[0] in args.events]

    for event_name, start_date, end_date, desc in target_events:
        print(f"\n{'='*70}")
        print(f"Event: {desc}")
        print(f"Window: {start_date} to {end_date}")
        print(f"{'='*70}")

        if not args.skip_flares:
            fetch_swpc_event_reports(start_date, end_date, event_name)

        if not args.skip_indices:
            fetch_kp_dst_indices(start_date, end_date, event_name)

        if not args.skip_forecasts:
            fetch_swpc_predictions(start_date, end_date, event_name)

        fetch_goes_xray_flux(start_date, end_date, event_name)

    print(f"\n{'='*70}")
    print(f"All data saved to: {DATA_DIR}")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
