# NOAA Data Collection for SmallSat Paper

## Setup (one time)

```
pip install -r requirements.txt
```

## Run

```
python fetch_noaa_data.py
```

This fetches data for all five target events. Takes about 5-10 minutes (rate-limited to avoid overloading NOAA servers).

To run a single event:
```
python fetch_noaa_data.py --events 2022_feb_starlink
```

## What the Script Produces

A `data/` folder with CSVs for each event:

| File | Contents |
|------|----------|
| `noaa_flare_events_<event>.csv` | Solar flare event reports (time, GOES class, location, region) |
| `noaa_forecasts_<event>.csv` | SWPC 3-day forecast probabilities (M-class %, X-class % for day 1/2/3) |
| `kp_index_<event>.csv` | Kp geomagnetic index (3-hour cadence, 0-9 scale) |
| `dst_index_<event>.csv` | Dst geomagnetic index (hourly, in nT) |
| `event_summary.csv` | Summary table of all events |

## Our Five Target Events

| Event ID | Dates | Description |
|----------|-------|-------------|
| 2022_feb_starlink | Jan 28 - Feb 15, 2022 | G1 storm, 38 Starlink sats lost (primary case study) |
| 2024_may_gannon | May 1 - May 18, 2024 | G5 storm, X8.7 flare, strongest in 20 years |
| 2024_oct_xflares | Sep 28 - Oct 10, 2024 | X7.1 + X9.0 from AR 3842 |
| 2024_dec_cluster | Dec 25, 2024 - Jan 5, 2025 | 3 X-class + 20 M-class in 24 hours |
| 2020_feb_quiet | Feb 1 - Feb 28, 2020 | Solar minimum baseline (false positive test) |

## After the Script Runs

### 1. Verify the CSVs

Open each CSV and check:
- `noaa_flare_events_*.csv` should have columns: date, begin_utc, max_utc, end_utc, goes_class, location, region
- `noaa_forecasts_*.csv` should have columns: date, m_class_day1_pct, x_class_day1_pct, etc.
- `kp_index_*.csv` should have columns: datetime_utc, kp
- `dst_index_*.csv` should have columns: datetime_utc, dst_nT

### 2. Manual Cross-Check (most important task)

Go to the NOAA SWPC archived reports and verify our data matches:

**For the Feb 2022 Starlink event (priority):**

1. Open https://www.ngdc.noaa.gov/stp/space-weather/swpc-products/daily_reports/reports_solar_geophysical_activity/2022/02/
2. Click on `20220203RSGA.txt` (the forecast issued on Feb 3, launch day)
3. Find the "Event Probabilities" section
4. Record the M-class and X-class flare probabilities for day 1, day 2, day 3
5. Compare against what our CSV shows for Feb 3
6. Do the same for `20220204RSGA.txt` (Feb 4, storm day)

**Key question to answer:** What M-class flare probability did NOAA assign for Feb 3-4, 2022? This is the number we compare Surya against in the paper.

7. Repeat the spot-check for 2-3 dates in each of the other four events

### 3. Save Your Notes

Create a file called `noaa_validation_notes.txt` in the `data/` folder documenting:
- Which dates you checked
- Whether the CSV values match the archived reports
- Any discrepancies found
- The exact NOAA forecast numbers for Feb 3-4, 2022

## Data Sources

| Data Product | Source | Archive |
|-------------|--------|---------|
| SGAS flare events | NOAA SWPC | ngdc.noaa.gov (NCEI archive) |
| RSGA forecasts | NOAA SWPC | ngdc.noaa.gov (NCEI archive) |
| Kp index | Extracted from SGAS reports | (Planetary K-indices line) |
| Dst index | WDC Kyoto | wdc.kugi.kyoto-u.ac.jp (provisional) |

## Troubleshooting

**Script runs but some data is missing:**
- Kp comes from the same SGAS files as flare events. If flare events work, Kp should too.
- Dst comes from WDC Kyoto (Japan). If their server is down, try again later.
- The quiet baseline (Feb 2020) will have 0 flare events. That is correct.

**Permission or SSL errors:**
- Some institutional networks block certain domains. Try from a personal connection.
- If WDC Kyoto is blocked, the script still produces flare events, forecasts, and Kp.
